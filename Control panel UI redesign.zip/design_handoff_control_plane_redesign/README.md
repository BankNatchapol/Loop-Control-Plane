# Handoff: Loop Control Plane — UI reorganization

## Overview
The Loop Control Plane is a local-first control plane for AI–human collaborative software
development. Its current UI is a **single endlessly-scrolling page** (`app/page.tsx`, ~6,400 lines):
repo badges, counter tiles, project metrics, the project toolbar, automation-policy text, project
health, the full Loop Engine panel, project/feature forms, the Feature + artifacts + Spec Kit
import panel, **and** the entire Workflow editor are all stacked **above** the kanban board. There
is no navigation — no tabs, no links — so a new user has no idea where to start.

This redesign splits that one page into **six tabbed sections** behind a **persistent context bar**
(project + feature selectors, plus global status badges) that stays visible everywhere. The goal:
make the app legible to a first-time user and give each concern its own room.

## About the Design Files
The files in this bundle are **design references created in HTML** — prototypes showing the
intended look, layout, and navigation, **not** production code to copy verbatim. The task is to
**recreate these designs inside the existing codebase** (Next.js 15 App Router + React +
Tailwind CSS v4, with `@xyflow/react` for the workflow graph and `lucide-react` icons), reusing
its established components and patterns. Nothing about the data model, API routes, or persisted
board format should change — this is a **presentation / information-architecture refactor only**.

The existing code already contains all the logic and most of the sub-components needed
(`MetricGroup`, `ProjectHealth`, `LoopEnginePanel`, `ProjectForm`, `FeatureForm`, `FeaturePanel`,
`WorkflowEditor`, the kanban board + `DndContext`, the task detail panel). The work is largely
**moving these existing blocks into tab panels** rather than rebuilding them.

## Fidelity
**High-fidelity.** Colors, typography, spacing, borders, and states match the app's current visual
language exactly (Tailwind slate/sky/emerald/rose/indigo, Arial, square corners, 1px borders). The
developer should reproduce it pixel-faithfully using the codebase's existing Tailwind classes — the
inline hex values in the prototype map directly to Tailwind tokens (see **Design Tokens**).

> Note: the prototype hardcodes sample data (project "auth-service", feature "Login & sessions",
> tasks T120–T162, etc.) purely to populate the screens. Wire each section to the real state that
> already exists in `page.tsx` — do not hardcode.

---

## Information Architecture

```
┌───────────────────────────────────────────────────────────────────────┐
│  APP BAR (persistent)                                                   │
│  ⟳ Loop Control Plane │ [▣ project ▾] [⛁ feature ▾] ········· [auto-run] [engine jobs] │
├───────────────────────────────────────────────────────────────────────┤
│  TAB STRIP:  Overview │ Board │ Features │ Workflows │ Engine │ Settings │
├───────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  ACTIVE TAB PANEL (max-width 1400px, centered, 24px gutters)            │
│                                                                         │
└───────────────────────────────────────────────────────────────────────┘
```

### Where today's blocks move

| Current block (in `page.tsx` header) | New home |
|---|---|
| Repo / branch badges | App bar (project selector) |
| Global auto-run badge, engine-jobs badge | App bar (right side) |
| Counter buttons (`counters`) + quick filters | **Overview** tiles (also drive **Board** filters) |
| `MetricGroup` ×4 (project metrics) | **Overview** + **Engine** |
| Project toolbar (add/edit/open/delete project, reload) | **Overview** actions + **Settings** |
| Global auto-run checkbox | **Engine** (global switch) |
| Feature selector buttons | App bar (feature selector) + **Features** |
| Effective Automation Policy block | **Engine** (run policy) |
| `ProjectHealth` | **Settings** |
| `LoopEnginePanel` | **Engine** |
| `ProjectForm` / `FeatureForm` (modal-ish inline forms) | Triggered from **Overview/Features/Settings**; render as overlay/drawer |
| `FeaturePanel` (artifacts + Spec Kit import) | **Features** |
| `WorkflowEditor` | **Workflows** |
| Kanban board + task detail panel | **Board** |

---

## Screens / Views

### 1. App Bar (persistent, every screen)
- **Layout:** horizontal flex, `max-width:1400px`, centered, `padding:10px 24px`, `border-bottom:1px solid slate-200`, `bg-white`. Wraps on narrow widths.
- **Left:** 26×26px `bg-slate-900` square with white `⟳` glyph + "Loop Control Plane" (15px, 700, slate-950). Then a 1px×22px slate-200 divider.
- **Project selector:** bordered control `border-slate-300`, `bg-white`, `px-2.5 py-1`, 12px/700 slate-700, folder glyph + name + `▾`. (Maps to the existing `<select>` for `selectProject`.)
- **Feature selector:** same but `border-slate-200 bg-slate-50`, 12px/600 slate-600. (Maps to `selectFeature`.)
- **Spacer** (`flex:1`), then two status badges, right-aligned:
  - Auto-run: when OFF → `border-rose-200 bg-rose-50 text-rose-700`, text "⚠ auto-run off"; when ON → `border-emerald-200 bg-emerald-50 text-emerald-700`, "global auto-run enabled". 11px/700 uppercase.
  - Engine jobs: `border-indigo-200 bg-indigo-50 text-indigo-800`, "⬡ N engine jobs". Bound to `engineStatus.activeJobCount`.

### 2. Tab Strip (persistent)
- Row of 6 text buttons, `padding:10px 16px`, 13px/600.
- **Active tab:** `border-bottom:2px solid sky-700 (#0369a1)`, text sky-800 (#075985).
- **Inactive:** transparent bottom border, text slate-500; hover → text slate-700.
- Tabs in order: **Overview, Board, Features, Workflows, Engine, Settings.**
- This is the only new navigation state: a single `activeTab` string. Persist it in the URL (`?tab=board`) or `localStorage` so reloads land in place.

### 3. Overview  *(default landing tab)*
- **Heading:** project name (22px/600 slate-950) + a one-line meta (12px slate-500: "Local-first … · path · branch"). Description paragraph (13px slate-600, max 70ch).
- **Counter row:** 6-column grid, `gap:10px`. Each tile: `border-slate-200 bg-white p-[11px_12px]`; label 11px/600 uppercase slate-500; value 24px/600 slate-950. (Open tasks 12 · In review 3 · Blocked 1 · Features 4 · AI owned 7 · Done today 5.) Reuse the existing `counters` array; clicking a tile may deep-link to Board with that quick filter applied.
- **Two-column body** (`1.1fr / 1fr`, `gap:16px`):
  - **Get started** card (`border-slate-200 bg-white`): uppercase section header on a `border-b`. 4 checklist rows, each `border-b border-slate-100`: a 20×20px status box (done = `bg-emerald-700` + white ✓; todo = `border-slate-300 bg-white`), label (done = slate-400 line-through; todo = slate-800/500), and a right-aligned action link (done = slate-400; todo = sky-700) that switches tabs. Steps: Connect a repository ✓ → Settings · Create a feature ✓ → Features · Generate tasks from the spec → Features · Turn on the Loop Engine → Engine.
  - **Latest workflow run** card: status pill (running = indigo), "feature-development-loop · step **implement**", an 8px progress bar (`bg-slate-100` track, `bg-sky-700` fill at 58%), and a meta line. Bind to `latestProjectWorkflowRun`.
  - **Recent activity** card: list rows, each a 7×7px colored square + text (12.5px slate-700) + right-aligned relative time (11px slate-400).

### 4. Board
- **Header row:** title + subtitle on the left; on the right, "Reload" (`border-slate-300 bg-white`) and "+ Add task" (`bg-slate-900 text-white`). Both 12px/600, `px-3 py-[7px]`.
- **Filter chips:** "All · AI owned · Mine · Blocked · High risk". Active chip = `border-sky-300 bg-sky-50 text-sky-800`; inactive = `border-slate-200 bg-white text-slate-500`. Bind to the existing `boardQuickFilter`.
- **Body grid** (`1fr / 300px`, `gap:16px`, `align-items:start`):
  - **Kanban** (`border-slate-200 bg-white`, horizontal scroll): columns 172px wide, `border-right:1px solid slate-200`. Column header `bg-slate-50`, `border-b`, uppercase 11px/700 slate-600 label + count (11px slate-400). Card lane `bg-[#fcfcfd]`, `min-height:240px`, `gap:8px`, `padding:10px`. **Cards:** `border-slate-200 bg-white p-[10px]`, `cursor:grab`; title 12px/600 slate-900 + a **risk pill** top-right (low = emerald, med = amber, high = rose; 9px/700 uppercase); footer row = **owner pill** (ai = indigo, human = slate) + task id (10.5px slate-400). Columns: Backlog, Planned, In progress, Review, Blocked, Done. Reuse the existing `DndContext` + drag handlers verbatim.
  - **Task detail panel** (`border-slate-200 bg-white`, `position:sticky; top:16px`): header (task id 11px slate-400, title 14px/700 slate-900, owner + mode pills); **Actions** section = 2×2 grid of bordered buttons (Assign AI · Claim · Run w/ Engine · Mark Done; 11.5px/600 slate-700); **Event timeline** = rows with a 7×7 slate-300 square, text 12px slate-700, time 10.5px slate-400.

### 5. Features
- **Header:** title + subtitle; "+ Add feature" button (`bg-slate-900 text-white`).
- **Lifecycle strip** (`border-slate-200 bg-white p-[11px_14px]`): pills Draft → Spec → Plan → Tasks → Shipped with slate-300 "→" separators. Done = emerald, active (Spec) = sky, todo = slate. Bind to `feature.status` via `featureStatusLabel`.
- **3-column body** (`180px / 1fr / 240px`, `gap:16px`, `align-items:start`):
  - **Artifacts list:** card with uppercase header; rows are file links. Active = `border-sky-300 bg-sky-50 text-sky-800` 600; approved (✓) = emerald text; others slate-600. (spec.md active · PRD.md ✓ · plan.md · notes.md.)
  - **Editor:** card, `min-height:340px`. Header = filename (13px/700) + status pill ("editing · unsaved", indigo). Body = monospace markdown preview (12px, line-height 1.8; headings slate-900/700, body slate-500). Footer (`border-t bg-slate-50`): Save (`bg-slate-900 text-white`), Reload (`border-slate-300 bg-white`), spacer, "Generate tasks →" (`border-emerald-200 bg-emerald-50 text-emerald-700`). Wire to the existing artifact load/save/approve handlers.
  - **Side column:** "Import Spec Kit" card with a `border-dashed slate-300 bg-slate-50` dropzone + "Choose folder…" button (maps to the Spec Kit preview/import flow); "Feature health" card with ✓/⚠ lines (emerald / rose).
- The inline **FeatureForm** opens from "+ Add feature" / "Edit" — render it as an overlay or right drawer rather than pushing page content down.

### 6. Workflows
- **Header:** title + subtitle. (Hosts the existing `WorkflowEditor` / `@xyflow/react` graph.)
- **2-column body** (`230px / 1fr`, `gap:16px`, `align-items:start`):
  - **Workflow list:** card; rows like the artifact list (active = sky). Plus a `border-dashed` "+ New workflow" button. (feature-development-loop active · bugfix-triage · review-and-merge.)
  - **Editor:** card. Header = workflow name (13px/700) + "▸ Run" button (`bg-slate-900 text-white`). Canvas area `bg-[#fcfcfd] p-[18px_14px]`: a horizontal step graph — pills with slate-300 "→" connectors, done = emerald, active (implement) = `bg-slate-900 text-white`, todo = `border-slate-300 bg-white`. Below it, a **Selected step** inspector card (`border-slate-200 bg-white`) showing agent + transition pills (success → review = emerald, fail → triage = rose). **In the real app this canvas is the existing `@xyflow/react` editor — keep it; only the surrounding chrome changes.**

### 7. Engine
- **Header:** title + subtitle.
- **Global auto-run banner** (`border-rose-200 bg-rose-50`, full width): bold "Global auto-run is OFF" (rose-700) + explanation (rose-800) on the left; "Turn on auto-run ▸" (`bg-slate-900 text-white`) on the right. When enabled, swap to an emerald banner. Bind to `automationSettings.globalAutoRunEnabled` / `toggleGlobalAutoRun`.
- **2-column body** (`1.2fr / 1fr`, `gap:16px`):
  - **Job queue** card: header with "Tick once" + "Run demo" buttons (11px/600, `border-slate-300 bg-white`). Rows (`border-b slate-100`): job title (12.5px/600 slate-900) + meta (11px slate-400) on the left, **status pill** on the right (running = indigo, queued = slate, blocked = rose). Bind to the engine status + `tickEngineOnce` / `runEngineDemoJob`.
  - **Run policy** card: rows with label (12.5px slate-700) + an ON/OFF toggle pill (on = emerald, off = slate). Closing line summarizes the **effective** policy (reuse `effectiveAutomationPolicy.message`).

### 8. Settings
- **Header:** title + subtitle.
- **2-column body** (`1fr / 1fr`, `gap:16px`):
  - **Backend availability** card: rows with label + status pill (available = emerald, not connected = amber). "Re-detect backends" button. Bind to `backendAvailability` / `loadBackendAvailability`.
  - **Repository & GitHub** card: key/value lines (path, branch, data dir, github status pill). Footer (`border-t bg-slate-50`): "Connect GitHub" (`bg-slate-900 text-white`) + "Set up labels" (`border-slate-300 bg-white`). Reuse the existing `ProjectHealth` GitHub connection/label setup handlers.

---

## Interactions & Behavior
- **Tab navigation:** clicking a tab swaps the active panel. Store `activeTab` in URL query (`?tab=`) or `localStorage` (`loop.activeTab`) so reload/back behave. Default = `overview`.
- **Cross-tab deep links:** Overview checklist actions and counter tiles switch tabs (and may pre-apply a Board filter).
- **Context bar selectors** drive the data shown in **every** tab — switching project/feature re-scopes Board, Features, Workflows, Engine, Settings simultaneously (this already happens via `selectProject` / `selectFeature`; just keep them mounted in the persistent bar).
- **Drag & drop:** unchanged — the Board tab hosts the existing `DndContext` with `handleDragEnd`.
- **Forms:** `ProjectForm` / `FeatureForm` should appear as overlays/drawers triggered from their tabs, instead of inline blocks that shift the layout.
- **Hover states:** buttons follow the existing convention — `hover:border-sky-300 hover:bg-sky-50 hover:text-sky-800` for secondary buttons; primary (slate-900) buttons darken slightly. Inactive tabs: text slate-500 → slate-700 on hover.
- **Status colors are semantic and must stay consistent:** sky = active/selected/info, emerald = healthy/on/success, rose = off/blocked/error, amber = warning/not-connected, indigo = engine/AI, slate = neutral.

## State Management
Reuse what already exists in `page.tsx`. The **only new state** is navigation:
- `activeTab: "overview" | "board" | "features" | "workflows" | "engine" | "settings"` — synced to URL/localStorage.
- Everything else (selected project/feature, board data, engine status, backend availability, artifact editor state, form modes, quick filter, mutation messages) is already modeled — it just gets distributed across tab panels instead of one scroll. Keep all data-loading effects mounted at the page level so switching tabs doesn't re-fetch.

## Design Tokens
The prototype's inline hexes map 1:1 to Tailwind classes already in use:

**Colors**
- Background `#f7f8fb` (page) · surface `#ffffff` · subtle surface `bg-slate-50 #f8fafc` · faint lane `#fcfcfd`
- Text: slate-950 `#020617`, slate-900 `#0f172a`, slate-700 `#334155`, slate-600 `#475569`, slate-500 `#64748b`, slate-400 `#94a3b8`
- Borders: slate-200 `#e2e8f0`, slate-300 `#cbd5e1`, slate-100 `#f1f5f9`
- Sky (active/info): border `#7dd3fc` / bg `#f0f9ff` / text `#075985`, accent `#0369a1`
- Emerald (success/on): border `#a7f3d0` / bg `#ecfdf5` / text `#047857`
- Rose (off/error): border `#fecdd3` / bg `#fff1f2` / text `#be123c`
- Amber (warning): border `#fde68a` / bg `#fffbeb` / text `#b45309`
- Indigo (engine/AI): border `#c7d2fe` / bg `#eef2ff` / text `#3730a3`

**Typography:** Arial, Helvetica, sans-serif (from `globals.css`). Scale: page H1 22px/600 · card title 13–14px/700 · body 12.5–13px · meta 11–12px · micro-label 11px/700 **uppercase** · counter value 24px/600. Markdown editor uses a monospace stack.

**Spacing:** content max-width 1400px, 24px gutters. Card padding 11–14px. Grid gaps 10–16px. Section dividers are 1px slate-200; row dividers 1px slate-100.

**Borders / radius / shadow:** 1px solid borders everywhere; **no border-radius (square corners)**; **no shadows** — depth comes from borders + background tints. This is the defining trait of the app's look — do not add rounded corners or drop shadows.

## Assets
- Icons: the app uses **`lucide-react`** (e.g. `ShieldAlert`, `Bot`, `FolderGit2`, `Plus`, `Pencil`, `FolderOpen`, `Code2`, `Trash2`, `Columns3`, `ListRestart`). The prototype substitutes simple unicode glyphs (⟳ ▣ ⛁ ⚠ ⬡ ▸ ✓) — replace these with the matching lucide icons in the real build.
- Workflow graph: **`@xyflow/react`** (already a dependency; styles imported in `layout.tsx`).
- No image assets.

---

## ✎ Alternative visual direction: Hand-drawn / sketch style

`Control Plane — Hand-drawn.dc.html` is the **same 6-tab IA** rendered in a hand-drawn,
"napkin sketch" aesthetic (the requested **Style A — full hand-drawn**). It is a complete,
production-intent design, not a throwaway wireframe. If you build this direction instead of the
clean slate/Tailwind one above, follow this section; the **information architecture, screens,
interactions, and state are identical** — only the visual layer changes.

### How to implement the look in a real React/Tailwind codebase
The effect is two independent ingredients — ship them together:

1. **Handwriting fonts** (biggest single effect — ~70% of the look)
   - Headings & big numbers: **Caveat** (Google Fonts, weights 500/600/700).
   - Body, labels, buttons, data: **Architects Daughter** (Google Fonts).
   - Load with `next/font/google` and expose as CSS variables, e.g.
     ```ts
     import { Caveat, Architects_Daughter } from "next/font/google";
     const caveat = Caveat({ subsets: ["latin"], variable: "--font-caveat" });
     const hand = Architects_Daughter({ subsets: ["latin"], weight: "400", variable: "--font-hand" });
     ```
   - Set `--font-hand` as the body font; use `--font-caveat` for `h1`/section titles and large metric numbers.

2. **Rough / wobbly borders & shapes** — three options, pick by effort vs. fidelity:
   - **Pure CSS (what the prototype uses, zero deps, recommended start):** give every card an
     *asymmetric* `border-radius` so the rectangle looks hand-drawn, a 2px solid ink border, and a
     hard offset shadow. Example utility:
     ```css
     .sketch-card {
       border: 2px solid #23221f;
       border-radius: 15px 12px 16px 13px / 13px 16px 12px 15px; /* the wobble */
       box-shadow: 3px 4px 0 rgba(35,34,31,.10);
       background: #fcfbf8;
     }
     ```
     Vary the four radius pairs slightly per element so no two boxes are identical (the prototype
     rotates through a small set of radius strings — see the `*Radii` arrays in its logic). Pills
     stay fully round (`border-radius: 999px`) with a 2px colored border.
   - **Rough.js** (`roughjs`) for genuinely sketchy SVG strokes — render card outlines / dividers /
     progress bars to an inline `<svg>` with `rough.svg(...).rectangle(...)`. Higher fidelity, more
     work; good for hero cards and the workflow-step connectors.
   - **Wired Elements** (`wired-elements`, web components: `wired-button`, `wired-card`,
     `wired-checkbox`, `wired-input`, `wired-progress`…) — drop-in rough-drawn controls built on
     Rough.js. Fastest way to get rough *interactive* widgets; wrap them as React components. Note
     they re-render their roughness on resize, so test inside the kanban scroll area.
   - For accent underlines / circles / strike-throughs on text, **rough-notation** (`rough-notation`)
     animates hand-drawn annotations.

### Hand-drawn design tokens
- **Paper background** `#f0ede3` (app) · card surface `#fcfbf8` · white control `#ffffff`.
- **Ink** `#23221f` (borders, dark buttons, primary text) · muted ink `#6f6d67` · faint `#9a978f`.
- **Accent pills** (2px border / tint bg / text): green `#86a87d / #eef5ea / #4a7340` (on, success,
  low risk) · blue `#6f97c7 / #eaf1fb / #3a5f96` (running, engine, info) · rose `#d08a7f / #fbeae6 /
  #b14b3c` (off, blocked, high risk) · amber `#d3a64e / #fbf2dd / #9a6a1c` (warning, not-connected,
  med risk) · violet `#8e7bbf / #efeafb / #5a4b8f` (AI owner).
- **Dividers:** `2px dashed #ddd9cd` inside cards (not solid).
- **Shadows:** always a hard offset `3px 4px 0 rgba(35,34,31,.10)` on cards, `2px 2px 0 …` on
  buttons/chips — never a soft blur.
- **Type scale:** page title Caveat 38px/700 · big metric Caveat 42px/700 · card title 17–21px/700 ·
  body 14.5–15px · meta 12–13px. (Everything ~2–4px larger than the clean version — handwriting
  reads smaller, so it needs more size.)
- **Active tab / primary button:** filled ink `#23221f` with cream `#f6f3ec` text.

### ⚠ Readability caveat (carry this into the build)
A 100% hand-drawn UI is charming but **measurably harder to read for dense data** — numbers, task
IDs (T140), code/markdown, and the kanban especially. Decisions for the developer / product owner:
- Consider keeping the **markdown editor body** and **monospace-ish data** in a clean legible font
  even within this theme (a pragmatic "mostly sketch" build).
- Ensure **min 14–15px** for handwriting body text; never go below 13px.
- Check color contrast — the tinted pills on paper can fall below WCAG AA; darken text tokens if so.
- The sketch font should not be used for anything safety-critical or numeric that must not be
  misread (e.g. exact counts in the engine queue) without a size bump.

---

## Files
- `Control Plane Redesign.dc.html` — **high-fidelity** redesign in the app's current slate/Tailwind look (all 6 tabs). Primary reference for the *clean* direction.
- `Control Plane — Hand-drawn.dc.html` — **high-fidelity** redesign in the **hand-drawn / sketch** look (all 6 tabs, Style A). Primary reference for the *sketch* direction. Same IA as above.
- `Control Plane Wireframes.dc.html` — the earlier **low-fidelity** sketch of the same IA (structure/flow only). Reference for intent.
- Target codebase (for reference, not in this bundle): `Loop-Control-Plane/app/page.tsx` (the page to refactor), `app/globals.css`, `app/layout.tsx`, and the product `README.md`.
